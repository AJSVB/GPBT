conda install -c conda-forge libgomp
pip3 install GPy
pip3 install sklearn
pip3 install tensorboardX
#pip install ray==1.2.0
pip3 install -U hyperopt
pip3 install torch==1.6.0
pip3 install torchvision==0.7.0

python3 This_is_actually_the_main.py
# install python packages for machine learning
#/usr/bin/yes | pip3.6 install --upgrade pip
#/usr/bin/yes | pip3.6 install cython cmake mkl mkl-include dill pyyaml setuptools cffi typing mako pillow matplotlib mpmath klepto
#/usr/bin/yes | pip3.6 install jupyter sklearn tensorflow keras spacy spacy_cld colored jupyterlab configparser gensim pymysql benepar tqdm wandb optuna bottleneck 
#/usr/bin/yes | pip3.6 install selenium networkx bs4 fuzzywuzzy python-levenshtein pyldavis newspaper3k  wikipedia nltk py-rouge beautifultable tensor2tensor tensorboardX benepar adabelief#-pytorch
#/usr/bin/yes | pip3.6 install --ignore-installed PyYAML
#/usr/bin/yes | pip3.6 install numpy==1.17.3
#/usr/bin/yes | pip3.6 install pandas==1.0.5
