
import models, datasets, schedulers, oracles, utils,main
import time
import torch
from hyperopt import hp, fmin, tpe, Trials
import os

n_configurations = 9 #Should be 24
total_iterations = 5  #Should be 50
epsilon = 1e-10
config = {
    "g_lr": hp.loguniform("g_lr",-8,-3),
    "d_lr": hp.loguniform("d_lr",-8,-3),
    "g_beta1": hp.uniform("g_beta1",.2,1-1e-6),
    "d_beta1" : hp.uniform("d_beta1",.2, 1-1e-6),
}

timen_now = time.time()
model = main.GAN
oracle = oracles.Guesser(config,0)
start_time = time.time()
scheduler = schedulers.Scheduler(model, total_iterations, n_configurations, oracle,1,True,1e100) #Should be 6
scheduler.initialisation()
scheduler.loop()
scheduler.close()
print("total exeuction time is " + str(time.time()-timen_now))
